package main.visitor;

import main.ast.core.Program;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


public class CodeGenerator extends Visitor<String> {
    private final String outputPath;
    private FileWriter writer;

    public CodeGenerator() {
        this.outputPath = "./codeGenOutput/";
        prepareOutputDirectory();
    }

    private void prepareOutputDirectory() {
        File dir = new File(outputPath);
        if (!dir.exists()) {
            dir.mkdirs();
        }
    }


    @Override
    public String visit(Program program) {
        try {
            initializeWriter();
            writeClassHeader();
            writeStaticFields(program);
            writeMainMethodHeader();
            generateBody();
            writeMainMethodFooter();
            closeWriter();
        } catch (IOException e) {}
        return null;
    }


    private void initializeWriter() throws IOException {
        writer = new FileWriter(outputPath + "Main.j");
    }

    private void writeClassHeader() throws IOException {
        writer.write(".class public Main\n");
        writer.write(".super java/lang/Object\n\n");
    }

    private void writeStaticFields(Program program) throws IOException {
       // ToDo
    }

    private void writeMainMethodHeader() throws IOException {
        writer.write(".method public static main([Ljava/lang/String;)V\n");
        writer.write("    .limit stack 128\n");
        writer.write("    .limit locals 128\n\n");
    }

    private void generateBody() throws IOException {
        // ToDo : Visit Children of program
    }

    private void writeMainMethodFooter() throws IOException {
        writer.write("\n    return\n");
        writer.write(".end method\n");
    }

    private void closeWriter() throws IOException {
        writer.close();
    }
}