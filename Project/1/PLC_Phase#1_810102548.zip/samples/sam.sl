main () {
    int a;
    a = 5;
    int b;
    b = a + 3;
}